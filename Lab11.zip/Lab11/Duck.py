class Duck:
    def selectDuck(val):
        if val == 1:
            display();
        elif val == 2:
            display();