class Quack:
    def quack():
        print("This duck can Quack..!")