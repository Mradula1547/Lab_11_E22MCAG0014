class flywithWings:
    def fly():
        print("This duck can fly..!")