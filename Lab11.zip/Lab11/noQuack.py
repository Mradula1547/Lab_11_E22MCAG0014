class noQuack:
    def noQuack():
        print("This duck can NOT Quack..!")