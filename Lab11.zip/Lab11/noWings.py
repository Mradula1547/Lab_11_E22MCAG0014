class noWings:
    def nowings():
        print("This bird can NOT Fly..!")