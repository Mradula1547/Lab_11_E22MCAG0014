class Squeak:
    def Squeak():
        print("This duck can Squeak..!")